$(window).load(function(){
    let dur = $('#videoPlayer').prop('duration')
    $('#introDuration').text(dur);
})